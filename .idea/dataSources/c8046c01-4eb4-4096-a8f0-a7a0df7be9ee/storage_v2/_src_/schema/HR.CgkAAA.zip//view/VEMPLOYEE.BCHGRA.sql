create view VEMPLOYEE as
select employees."EMPLOYEE_ID",employees."FIRST_NAME",employees."LAST_NAME",employees."EMAIL",employees."PHONE_NUMBER",employees."HIRE_DATE",employees."JOB_ID",employees."SALARY",employees."COMMISSION_PCT",employees."MANAGER_ID",employees."DEPARTMENT_ID", jobs.job_title, departments.department_name
from employees, jobs, departments
where employees.department_id = departments.department_id
and employees.job_id = jobs.job_id
/

